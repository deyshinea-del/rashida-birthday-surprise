# Rashida Birthday Website

Romantic birthday mini-site with a passcode screen.

Default passcode: `RASHIDA`

Change `const SECRET="RASHIDA";` in index.html before publishing if you want a different code.

Publish the folder to GitHub Pages, Netlify, Vercel, or another static web host.
